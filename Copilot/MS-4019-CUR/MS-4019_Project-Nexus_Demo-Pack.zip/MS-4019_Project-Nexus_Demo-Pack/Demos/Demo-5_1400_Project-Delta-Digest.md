# MS-4019 · A Day with Project Nexus

## Demo 5 · 14:00 · Project Delta Digest · EXECUTE
*MS-4019: Tools to create agents, components of an agent, creating an agent in Copilot Chat (Describe and Configure), testing and editing agents*

| | |
|---|---|
| **Overview** | An agent template that produces a daily or weekly digest of **what changed** on a project: completed, in progress, blockers and risks, each with a source. |
| **Business scenario** | Arjun spends 2 hours every Friday chasing six leads for status. The Finance workshop blocker sat unnoticed for 8 days. |
| **Pain points** | Manual status reporting · risks found too late · a different report format every week |
| **Business benefits** | Status work cut from 2 hours to 10 minutes · blockers flagged with owner and days stuck · a consistent leadership format |
| **Learning objectives** | Create an agent from a template · identify and edit its components · test and edit an agent · schedule a digest |
| **Environment setup** | Agent Builder available · Project Delta Digest template (or `Agent-Instructions/Project-Delta-Digest_Instructions.md`) · Project Nexus SharePoint site with the sample files |

### Demo walkthrough: build
1. In Copilot Chat, select **New agent**, open the template gallery and choose **Project Delta Digest**.
2. On the **Describe** tab:
```
Tailor this agent for Project Nexus. Group the digest by workstream and include owner names.
```
3. On the **Configure** tab, walk through the **components of an agent**:
   - **Name:** `Nexus Delta Digest`
   - **Description:** short and precise
   - **Instructions:** add `Flag items with no update for 5 or more working days as STALE. Never invent figures.`
   - **Knowledge:** the Project Nexus SharePoint site
   - **Starter prompts:** Daily digest · Blockers · Leadership recap
4. Select **Create**.

### Demo walkthrough: test and edit
5. Test for accuracy:
```
Give me today's Project Nexus digest: TL;DR, completed, in progress, blockers (owner, days stuck) and risks. Cite sources.
```
*Expected:* two **Blocked** Finance items (workshops, template enablement) marked STALE with their owners.
6. Test an edge case:
```
What is the budget variance for the Sales workstream?
```
*Expected:* "Not found in sources." If it guesses, tighten the instructions, update the agent and test again.
7. Test the leadership format:
```
Give me a one-page leadership digest for Project Nexus: TL;DR, milestones, top 3 risks, and the one decision I need.
```

### 🔁 Schedule it
| Name | Frequency | Time | Prompt |
|---|---|---|---|
| Daily project delta | Daily | 10:00 AM | The digest prompt from step 5 |
| Leadership recap | Weekly, Friday | 4:00 PM | The leadership prompt from step 7 |

**Teaching moment:** *Start from a template, tailor it, test it, **schedule** it. That's how business users build agents.*

> **➡ Story:** *"With the plan approved, Arjun's team is flooded with questions: How do I get a licence? Who is my champion?"*

