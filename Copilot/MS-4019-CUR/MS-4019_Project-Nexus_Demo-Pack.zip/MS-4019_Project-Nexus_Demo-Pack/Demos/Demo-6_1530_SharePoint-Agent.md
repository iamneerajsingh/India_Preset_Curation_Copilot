# MS-4019 · A Day with Project Nexus

## Demo 6 · 15:30 · SharePoint agent + sharing · SCALE
*MS-4019: Creating an agent in SharePoint, managing agents, sharing agents, sharing in Teams, interacting with agents*

**Use case:** Arjun creates a **Nexus Help Desk** agent on the project site so the team can answer their own questions. He also shares his Delta Digest with the workstream leads.

### Demo walkthrough
1. On the **Project Nexus** SharePoint site, select **Create an agent**. Name it `Nexus Help Desk`, with sources `Nexus_Team_FAQ.docx` and `Nexus_Rollout_Plan.docx`.
2. Test it:
```
How do I get a Copilot licence, and who is the Finance champion?
```
3. Copy the agent link, post it in the **Nexus Teams chat** and **@mention** the agent.
4. Share **Nexus Delta Digest** with specific users (the workstream leads).

**Key points:** shared agents **respect permissions**, so sharing an agent doesn't share its files · a site owner can set the site's **default agent** · your chats with agents are private to you.

> **➡ Story:** *Priya: "Great. You'll run the Finance agent workshops yourself next week." Arjun knows Copilot, but can he teach agents?*

