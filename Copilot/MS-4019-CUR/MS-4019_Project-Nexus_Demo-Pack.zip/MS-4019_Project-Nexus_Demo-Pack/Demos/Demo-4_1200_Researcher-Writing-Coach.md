# MS-4019 · A Day with Project Nexus

## Demo 4 · 12:00 · Researcher + Writing Coach · RECOMMEND
*MS-4019: Researcher agent, Writing Coach agent*

| | |
|---|---|
| **Overview** | Researcher does multi-step research across your work data and the web and returns a cited report. Writing Coach turns it into a clear executive message. |
| **Business scenario** | Arjun needs a recommendation for recovering Finance adoption, backed by internal context and proven practice, sent to Priya before lunch ends. |
| **Pain points** | Research spread across mail, files and the web · recommendations without evidence · long, unclear leadership emails |
| **Business benefits** | A sourced recommendation in about 15 minutes · better decisions · crisp communication with leadership |
| **Learning objectives** | Run a cited research report · choose between Copilot Chat and Researcher · refine a message with Writing Coach |
| **Environment setup** | Researcher and Writing Coach available · Project Nexus files accessible · web grounding allowed |

### Demo walkthrough
1. Open **Researcher** and run the prompt. Point out its clarifying questions and research plan.
```
Goal: Recommend how to recover Copilot agent adoption in our Finance business unit within 60 days.
Context: Finance weekly active users fell ~30% in 3 weeks. Training completion is 26% and users see no role-relevant use cases.
Source: My email, meetings and Project Nexus files, plus credible external adoption guidance.
Expectations: 1 page: 3 options (effort, impact, risk), a recommendation, a 30-day plan. Cite sources.
```
2. Review the **citations** in the report.
3. Open **Writing Coach**:
```
Rewrite this as a note to my VP, under 100 words, confident and clear, with one ask: [paste the recommendation]
```

*Expected recommendation:* role-based Finance workshops, Finance champions, and every attendee leaving with scheduled prompts.

**Teaching moment:** *Copilot Chat for a quick answer · **Researcher** for depth and citations · **Coaches** for better thinking and writing.*

> **➡ Story:** *Priya replies: "Approved. But why did I hear about the Finance blockers three weeks late?" Arjun decides he'll never chase status again.*

