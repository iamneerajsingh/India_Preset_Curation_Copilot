# MS-4019 · A Day with Project Nexus

## Demo 7 · 16:30 · AI Learning Advisor · GROW
*MS-4019: Who can create and use agents (from business user to maker)*

| | |
|---|---|
| **Overview** | An agent template grounded in **Microsoft Learn**. It gives personalised learning plans and trusted answers with links. |
| **Business scenario** | Arjun has to teach Finance users about agents next week. His gaps are knowledge sources, Agent Builder vs Copilot Studio, and governance. |
| **Pain points** | Too many resources and no clear path · no time to learn · the same questions sent to experts again and again |
| **Business benefits** | A focused learning plan in minutes · trusted answers with sources · continuous skill growth |
| **Learning objectives** | Build a personalised learning plan · use an adaptive knowledge check · schedule a weekly learning check-in |
| **Environment setup** | AI Learning Advisor available (or `Agent-Instructions/AI-Learning-Advisor_Instructions.md`) · web grounding allowed |

### Demo walkthrough
1. Add and open **AI Learning Advisor**.
2. Build the plan:
```
Goal: Make me confident explaining Microsoft 365 Copilot agents to finance professionals.
Context: I'm comfortable with Copilot and prompting. My gaps: knowledge sources, Agent Builder vs Copilot Studio, sharing and governance. I have 3 hours a week for 4 weeks.
Source: Microsoft Learn.
Expectations: Table: Week | Skill | Learning (link) | Hands-on | How I'll know I've learned it.
```
3. Make it adaptive:
```
Quiz me with 3 questions, one at a time, then adjust my plan.
```
4. Answer the question every audience asks:
```
What's the difference between Agent Builder and Copilot Studio, and which should a finance user start with?
```

### 🔁 Schedule it
| Name | Frequency | Time | Prompt |
|---|---|---|---|
| Learning check-in | Weekly, Monday | 4:00 PM | `I'm a Program Manager learning Copilot agents. Give me this week's one skill, a 20-minute Microsoft Learn activity with a link, and one question on last week's topic.` |

**Teaching moment:** *Content discovery gives you a list. **Personalised learning** gives you a path, and the schedule keeps you on it.*

> **➡ Story:** *"It's 5:30. Arjun's day started with 200 unread items and no plan. Let's see what he's set up for tomorrow."*

