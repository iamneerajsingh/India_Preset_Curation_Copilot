# MS-4019 · A Day with Project Nexus

## Demo 3 · 11:00 · Analyst · INVESTIGATE
*MS-4019: Analyst agent*

| | |
|---|---|
| **Overview** | Analyst reasons step by step over your data files and runs Python, and you can see and check its code. |
| **Business scenario** | Arjun needs to show Priya **why** Finance adoption is falling, with evidence. |
| **Pain points** | No analyst available · pivots and charts take hours · hard to tell a trend from noise |
| **Business benefits** | Data-backed answers in minutes · transparent, checkable reasoning · charts ready for leadership |
| **Learning objectives** | Analyse a file with natural language · review Analyst's reasoning and code · turn findings into an insight |
| **Environment setup** | Analyst available · `Nexus_Adoption_Data.xlsx` saved to OneDrive |

### Demo walkthrough
1. Open **Analyst** and attach `Nexus_Adoption_Data.xlsx`.
2. Find the trend:
```
Show weekly active users by business unit over the last 8 weeks as a line chart. Which business unit is declining, since when, and by how much?
```
3. Find the cause:
```
For that business unit, compare training completion, survey sentiment and the pulse survey comments with the others. What are the 3 most likely reasons for the decline? Show the evidence.
```
4. Expand the **reasoning / code** panel: *"You can check its work."*

*Expected:* Finance weekly active users are down about 30% over 3 weeks. Training completion is stuck at 26%, and survey comments say "no role-relevant use cases" and "not trained on agents."

**Teaching moment:** *Ask questions of data the way you'd ask a colleague, and check the working.*

> **➡ Story:** *"Now Arjun knows **why**. Priya will ask **what we should do about it**."*

