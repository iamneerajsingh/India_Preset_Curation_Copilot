# MS-4019 · A Day with Project Nexus

## Demo 1 · 8:30 · Personal News Digest · UNDERSTAND
*MS-4019: What are agents (prebuilt, template and custom agents), and who can use them*

| | |
|---|---|
| **Overview** | An agent template grounded in your email, Teams and SharePoint. It turns company-wide announcements into a short digest of what matters to **your** role. |
| **Business scenario** | Arjun opens his laptop to a CEO note on AI, a policy deadline, an outage notice and dozens of newsletters. Two of them matter for today. |
| **Pain points** | Important updates get lost in the noise · required actions are missed · 30–45 minutes a day spent scanning |
| **Business benefits** | A 3-minute read instead of a 30-minute scan · no missed deadlines · faster alignment with leadership |
| **Learning objectives** | Explain prebuilt vs template vs custom agents · add an agent from a template · schedule a daily briefing |
| **Environment setup** | Personal News Digest available in the Agent Store or template gallery · announcements in your mailbox (or paste `Nexus_Sample_Announcements.md`) |

### Demo walkthrough
1. In Copilot Chat, go to **Agents → Get agents**, search for **Personal News Digest** and select **Add**.
2. Point out the conversation starters: *"It's a template. Microsoft wrote the instructions, so you just use it."*
3. Run the briefing prompt:
```
Goal: Give me a morning briefing of what changed that matters to my work.
Context: I'm a Program Manager leading our Microsoft 365 Copilot and agents rollout (Project Nexus).
Source: Company-wide announcements from my email, Teams and SharePoint news in the last 24 hours.
Expectations: Top 5 only, as a table: Priority (Critical/Important/FYI) | Headline | Why it matters to me | Action & deadline.
```
4. Ask the follow-up:
```
Which one item should I raise with my VP today, and why?
```
*Expected:* the CEO's message asking every team to adopt agent workflows, plus the notice that new agent templates are live for everyone **except Finance**.

### 🔁 Schedule it
| Name | Frequency | Time | Prompt |
|---|---|---|---|
| Morning briefing | Daily | 8:30 AM | The briefing prompt above |

**Teaching moment:** *Search asks "what happened?" This agent asks "what happened **that matters to me**?"*

> **➡ Story:** *"Finance is falling behind, and the CEO is watching. But Arjun's calendar is already full. What actually matters today?"*

