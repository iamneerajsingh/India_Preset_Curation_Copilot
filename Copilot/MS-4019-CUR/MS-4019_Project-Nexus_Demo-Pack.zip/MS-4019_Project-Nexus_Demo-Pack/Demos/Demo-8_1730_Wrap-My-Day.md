# MS-4019 · A Day with Project Nexus

## Demo 8 · 17:30 · Wrap my day · SUSTAIN
*MS-4019: IT governance for agents, interacting with agents, learning path review*

### Demo walkthrough
1. In **Plan My Day**, run Arjun's end-of-day prompt:
```
Wrap my day: what I completed, what slipped, decisions I owe, and tomorrow's top 3 priorities.
```
2. Open the **Scheduled prompts** list and show Arjun's agentic day:

| Time | Agent | Scheduled prompt | Frequency |
|---|---|---|---|
| 8:30 | Personal News Digest | Morning briefing | Daily |
| 9:00 | Plan My Day | Start my day | Daily |
| 10:00 | Project Delta Digest | Daily project delta | Daily |
| 18:00 | Plan My Day | Wrap my day | Daily |
| Fri 16:00 | Project Delta Digest | Leadership recap | Weekly |
| Mon 16:00 | AI Learning Advisor | Learning check-in | Weekly |

> *"About five minutes of reading a day. Arjun no longer goes looking for information; it comes to him, every working day."*

3. **Governance check:**
   - Agents and scheduled prompts only use data you can already access.
   - Sensitivity labels and data loss prevention still apply.
   - Pause schedules you don't read.
   - Your organisation controls which agents are available.

### 🔁 Your turn: Schedule 3
1. Pick **3 prompts** from the prompt pack below, at least **2 of them daily**.
2. Personalise them (role, project, priorities) and run each one once.
3. **Schedule** each one, then post **"✅ 3 scheduled"** in the class chat.

### Epilogue: the next morning
> *8:30. Arjun opens Copilot. His briefing is waiting. At 9:00 his day is planned. At 10:00 the Nexus digest shows Finance training is finally scheduled. He didn't ask for any of it. **The agents came to him.***
>
> *"Tomorrow at 8:30, yours will be waiting too."*

