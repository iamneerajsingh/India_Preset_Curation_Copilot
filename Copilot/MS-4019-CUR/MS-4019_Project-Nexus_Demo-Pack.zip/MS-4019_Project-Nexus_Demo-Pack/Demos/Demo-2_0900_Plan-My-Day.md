# MS-4019 · A Day with Project Nexus

## Demo 2 · 9:00 · Plan My Day + Prompt Coach · PRIORITIZE
*MS-4019: Prompt Coach agent, and the benefits of using agents*

| | |
|---|---|
| **Overview** | Plan My Day combines meetings, email, Teams and tasks into one time-blocked plan, and **re-plans** when things change. Prompt Coach improves the prompt before it's scheduled. |
| **Business scenario** | 9 meetings, a status report to prepare, a stuck workstream, and 30 minutes of learning to protect. Then Priya asks for a Finance deep-dive **today**. |
| **Pain points** | No single view of the day · urgent work pushes out important work · re-planning by hand after every interruption |
| **Business benefits** | ~20 minutes saved every day · focus time protected · a clear start and end to every day |
| **Learning objectives** | Improve a prompt with Prompt Coach · plan and re-plan with an agent · schedule start-of-day and end-of-day prompts |
| **Environment setup** | Plan My Day and Prompt Coach available · a real calendar with meetings today |

### Demo walkthrough
1. Open **Prompt Coach** and improve Arjun's first attempt:
```
Improve this prompt for a Program Manager using Goal, Context, Source and Expectations: "plan my day"
```
2. Open **Plan My Day** and run the improved prompt:
```
Goal: Create a realistic, focused plan for today.
Context: I'm a Program Manager. Today I must update leadership on Project Nexus, unblock a delayed workstream, attend my meetings, and keep 30 minutes for learning.
Source: My calendar, recent email and Teams messages, and tasks.
Expectations: Table: Time | Activity | Priority | Why now. Then my top 3 outcomes and what I can postpone.
```
3. **Plot twist:** a message arrives from Priya.
```
My VP needs a deep-dive on falling Finance adoption today, with a recommendation. Re-plan my day, protect my top 3 outcomes, and tell me what to decline or delegate.
```

### 🔁 Schedule it
| Name | Frequency | Time | Prompt |
|---|---|---|---|
| Start my day | Daily | 9:00 AM | The plan prompt from step 2 |
| Wrap my day | Daily | 6:00 PM | `Wrap my day: what I completed, what slipped, decisions I owe, and tomorrow's top 3 priorities.` |

**Teaching moment:** *Making a plan is useful. **Re-planning when things change** is where an agent earns its place.*

> **➡ Story:** *"The deep-dive is now at 11:00. Arjun has the adoption data, but no time to analyse it."*

