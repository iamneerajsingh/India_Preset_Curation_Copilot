# Sample company announcements (Demo 1)
Use these if your mailbox has few company-wide announcements. Paste them into Copilot Chat with:
`Treat the following as my company announcements from the last 24 hours. I am a Program Manager leading our Copilot rollout. Give me the top 5 that matter to me as a table: Priority – Headline – Why it matters to me – Action & deadline.`

---
1. **From: Office of the CEO** · *Subject: Agents are how we will work in 2027.* "Every team will identify two agent-powered workflows by Q1. Adoption will be part of our transformation scorecard."
2. **From: Information Security** · *Subject: Updated data handling policy (action required by 15 Nov).* All employees must complete the 20-minute "AI and data handling" module.
3. **From: HR** · *Subject: Performance cycle opens 3 Nov.* Self-reviews due 21 Nov.
4. **From: IT Service Desk** · *Subject: Planned outage, Saturday 1 Nov, 22:00–02:00.* SharePoint and Teams read-only during migration.
5. **From: Facilities** · *Subject: Cafeteria menu changes.* New menu from Monday.
6. **From: Finance Leadership** · *Subject: Month-end close moved earlier.* Close for October completes on 3 Nov instead of 5 Nov.
7. **From: Learning & Development** · *Subject: AI Learning Week, 17–21 Nov.* Register for role-based agent sessions.
8. **From: Corporate Communications** · *Subject: Contoso wins Digital Transformation award.* Celebration townhall on 6 Nov.
9. **From: Microsoft 365 Admin** · *Subject: New agent templates available.* Project Delta Digest and AI Learning Advisor now available to Wave 2 users (Finance pending).
10. **From: Sports Club** · *Subject: Cricket tournament registrations.* Teams of 11 by 10 Nov.
